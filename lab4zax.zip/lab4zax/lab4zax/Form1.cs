﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Collections;

namespace lab4zax
{
    public partial class Form1 : Form
    {
        Dictionary<char, double> letters = new Dictionary<char, double>();
        public Dictionary<string, double> combs = new Dictionary<string, double>();
        public Form1()
        {
            InitializeComponent();
            openFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            chart1.ChartAreas[0].AxisX.Interval = 1;
            chart1.Series["A"].Color = System.Drawing.Color.ForestGreen;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            string filename = openFileDialog1.FileName;
            textBox1.Text = filename;
        }
        public void ChactotaLettes(Dictionary<char, double> letters, Dictionary<string, double> combs, int totalCount, string Types)
        {
            if (Types == "Letter")
            {
                int countKeys = letters.Keys.Count;
                char[] Keys = new char[countKeys];
                letters.Keys.CopyTo(Keys, 0);
                for (int i = 0; i < countKeys; i++)
                {
                    letters[Keys[i]] /= totalCount;
                }
            }
            else
            {
                int countKeys = combs.Keys.Count;
                string[] Keys = new string[countKeys];
                combs.Keys.CopyTo(Keys, 0);
                for (int i = 0; i < countKeys; i++)
                {
                    combs[Keys[i]] /= totalCount;
                }
            }
        }
        public void LettersDict(string Text, Dictionary<char, double> letters, int textLength)
        {
            int i = 0;
            double letterRecur = 1;
            i = 0;

            while (i < textLength)
            {
                if (!letters.ContainsKey(Text[i]) && Char.IsLetter(Text[i]))
                {
                    letters.Add(Text[i], letterRecur);
                }
                else
                    if (letters.ContainsKey(Text[i]))
                {
                    letters[Text[i]]++;
                }
                i++;
            }
        }

        public void BigramsDict(string Text, Dictionary<string, double> bigrams, int textLength)
        {
            string bigram;
            double lettersRecur = 1;

            for (int i = 0; i < textLength - 1; i++)
            {
                bigram = string.Concat(Text[i], Text[i + 1]);

                if (!bigrams.ContainsKey(bigram) && Char.IsLetter(Text[i]) && Char.IsLetter(Text[i + 1]))
                {
                    bigrams.Add(bigram, lettersRecur);
                }
                else
                    if (bigrams.ContainsKey(bigram))
                {
                    bigrams[bigram]++;
                }
            }
        }

        public void TriplegramsDict(string Text, Dictionary<string, double> trigleramsDict, int textLength)
        {
            string trigram;
            double chrctrRecur = 1;

            for (int i = 0; i < textLength - 2; i++)
            {
                trigram = string.Concat(Text[i], Text[i + 1], Text[i + 2]);

                if (!trigleramsDict.ContainsKey(trigram) && Char.IsLetter(Text[i]) && Char.IsLetter(Text[i + 1]) && Char.IsLetter(Text[i + 2]))
                {
                    trigleramsDict.Add(trigram, chrctrRecur);
                }
                else
                    if (trigleramsDict.ContainsKey(trigram))
                {
                    trigleramsDict[trigram]++;
                }
            }
        }
        public void View(Dictionary<char, double> letters, Dictionary<string, double> ngrams, int totalCount, string Types)
        {
            if (Types == "Letter")
            {
                if (radioButton1.Checked)
                {
                    SortedDictionary<char, double> sortedDict = new SortedDictionary<char, double>(letters);
                    foreach (KeyValuePair<char, double> c in sortedDict)
                    {
                        this.chart1.Series["A"].Points.AddXY(c.Key.ToString(), c.Value);
                    }
                }
                else if (radioButton2.Checked)
                {
                    var items = from pair in letters
                                orderby pair.Value descending
                                select pair;

                    foreach (KeyValuePair<char, double> c in items)
                    {
                        this.chart1.Series["A"].Points.AddXY(c.Key.ToString(), c.Value);
                    }
                }
                else if (radioButton3.Checked)
                {
                    var items = from pair in letters
                                orderby pair.Value descending
                                select pair;

                    foreach (KeyValuePair<char, double> c in items)
                    {
                        listBox1.Items.Add(c.Key.ToString());
                    }
                }
            }
            else
            {
                int max = 30,
                    i = 1;

                var items = from pair in ngrams
                            orderby pair.Value descending
                            select pair;

                foreach (KeyValuePair<string, double> c in items)
                {
                    if (i > max)
                        break;
                    else
                    {
                        if ((radioButton2.Checked))
                            this.chart1.Series["A"].Points.AddXY(c.Key.ToString(), c.Value);
                        else if((radioButton3.Checked))
                        listBox1.Items.Add(c.Key.ToString() + "\t" + Math.Round(c.Value,5));
                        i++;
                    }
                }
            }
        }
        public void ReadText(string pathFile, Dictionary<char, double> letters, Dictionary<string, double> ngrams, out int totalCount, string Types)
        {
            string Text = File.ReadAllText(pathFile).ToLower();
            totalCount = Text.Length;

            switch (Types)
            {
                case "Letter":
                    LettersDict(Text, letters, totalCount);
                    break;
                case "Bigram":
                    BigramsDict(Text, ngrams, totalCount);
                    break;
                case "Triplegram":
                    TriplegramsDict(Text, ngrams, totalCount);
                    break;
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "Letter")
            {
                radioButton1.Enabled = true;
                radioButton2.Enabled = true;
                radioButton3.Enabled = true;
                radioButton1.Checked = true;
                button5.Enabled = true;
                button6.Visible = false;  
            }
            else if (comboBox1.SelectedItem.ToString() == "Bigram")
            {
                radioButton1.Enabled = false;
                radioButton2.Enabled = true;
                radioButton3.Enabled = true;
                radioButton2.Checked = true;
                button5.Enabled = true;
            }
            else if (comboBox1.SelectedItem.ToString() == "Triplegram")
            {
                radioButton1.Enabled = false;
                radioButton2.Enabled = true;
                radioButton3.Enabled = true;
                radioButton2.Checked = true;
                button5.Enabled = true;
                button6.Visible = false;
            }
        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.Enabled = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.Enabled = false;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            listBox1.Enabled = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            chart1.Visible = true;
            dataGridView1.Visible = false;
            chart1.Series[0].Points.Clear();
            listBox1.Items.Clear();
            string analTypes;
            int CountLetters;
            analTypes = comboBox1.SelectedItem.ToString();
            ReadText(textBox1.Text, letters, combs, out CountLetters, analTypes);
            ChactotaLettes(letters, combs, CountLetters, analTypes);
            View(letters, combs, CountLetters, analTypes);
            if(comboBox1.SelectedItem.ToString() == "Bigram")
            button6.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            chart1.Visible = false;
            dataGridView1.Visible = true;
            chart1.Series[0].Points.Clear();
            listBox1.Items.Clear();
            ArrayList x = new ArrayList();
            ArrayList y = new ArrayList();

            foreach (KeyValuePair<string, double> keyValue in combs)
            {
                if (!x.Contains(keyValue.Key[0]))
                {
                    x.Add(keyValue.Key[0]);
                }
                if (!y.Contains(keyValue.Key[1]))
                {
                    y.Add(keyValue.Key[1]);
                }
            }
            dataGridView1.Size = new Size(1060,600);
            dataGridView1.RowCount = x.Count;
            dataGridView1.ColumnCount = y.Count;
            dataGridView1.RowHeadersWidth = 50;
            int i, j;
            for (i = 0; i < x.Count; ++i)
            {
                for (j = 0; j < y.Count; ++j)
                {
                    dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.White;
                    foreach (KeyValuePair<string, double> keyValue in combs)
                    {
                        if (keyValue.Key == String.Concat(x[i], y[j]))
                        {
                            if (keyValue.Value > 0.008)
                            {
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.Purple;
                            }
                            else if (keyValue.Value <= 0.008 && keyValue.Value > 0.007)
                            {
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.Blue;
                            }
                            else if (keyValue.Value <= 0.007 && keyValue.Value > 0.006)
                            {
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.Aqua;
                            }
                            else if (keyValue.Value <= 0.006 && keyValue.Value > 0.005)
                            {
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.ForestGreen;
                            }
                            else if (keyValue.Value <= 0.005 && keyValue.Value > 0.004)
                            {
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.Lime;
                            }
                            else if (keyValue.Value <= 0.004 && keyValue.Value > 0.003)
                            {
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.Yellow;
                            }
                            else if (keyValue.Value <= 0.003 && keyValue.Value > 0.002)
                            {
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.Orange;
                            }
                            else if (keyValue.Value <= 0.002 && keyValue.Value > 0.001)
                            {
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.Red;
                            }
                            else
                            {
                                dataGridView1.Rows[i].Cells[j].Style.BackColor = Color.Gray;
                            }
                        }
                    }
                }
            }

            for (int k = 0; k < y.Count; k++)
            {
                dataGridView1.Columns[k].Name = y[k].ToString();
                dataGridView1.Columns[k].Width = 30;
            }

            for (int k = 0; k < x.Count; k++)
            {
                dataGridView1.Rows[k].HeaderCell.Value = x[k].ToString();
            }
        }

        private void chart1_Click(object sender, EventArgs e)
        {
        }
    }
}
